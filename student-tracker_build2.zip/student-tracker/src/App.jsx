import React from 'react'
import StudentForm from './components/StudentForm.jsx'
import StudentList from './components/StudentList.jsx'

// App composes the form (Create) and the list (Read) to satisfy exam requirements.
const App = () => {
  return (
    <main>
      <header className="card" style={{ marginBottom: '1.25rem' }}>
        <h1 style={{ margin: 0 }}>Student Tracker</h1>
      </header>
      <StudentForm />
      <StudentList />
    </main>
  )
}

export default App
