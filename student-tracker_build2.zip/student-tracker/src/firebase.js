// Firebase v10 modular SDK setup for Firestore
// We read all credentials from Vite env variables prefixed with VITE_*
import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'

// The config is kept out of source control via .env. Vite exposes env vars
// on import.meta.env at build time.
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID
}

// Initialize the Firebase app instance once and export Firestore (db).
// getFirestore() links the database instance to this app.
const app = initializeApp(firebaseConfig)
export const db = getFirestore(app)
