import React, { useState } from 'react'
import { collection, addDoc, serverTimestamp } from 'firebase/firestore'
import { db } from '../firebase'

// This controlled form handles the "Create" part of CRUD.
// It sends a new student { name, course } document to Firestore on submit.
const StudentForm = () => {
  // Local state to keep form inputs in sync with UI
  const [name, setName] = useState('')
  const [course, setCourse] = useState('')

  // UI helpers to show feedback from async operations
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState('')

  // Handler for the submit event
  const handleSubmit = async (e) => {
    e.preventDefault() // Stop the default full-page form submission
    setError(null)
    setSuccess('')

    // Guard clause: basic validation so we don't write empty data
    if (!name.trim() || !course.trim()) {
      setError('Please enter both name and course.')
      return
    }

    setIsSubmitting(true)
    try {
      // Reference to the 'students' collection in Firestore.
      // If it doesn't exist yet, Firestore will create it on first write.
      const studentsRef = collection(db, 'students')

      // addDoc adds a new document with a random ID to the collection.
      // We also attach a createdAt timestamp to make ordered reads easier.
      await addDoc(studentsRef, {
        name: name.trim(),
        course: course.trim(),
        createdAt: serverTimestamp()
      })

      // If the write succeeds, clear the form so the user sees a fresh state.
      setName('')
      setCourse('')
      setSuccess('Student saved successfully.')
    } catch (err) {
      // Log the full error to the console for debugging (per exam spec).
      console.error('Error adding student:', err)
      setError('Something went wrong while saving. Check console for details.')
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div style={styles.wrapper}>
    <div style={styles.card}>
      <h2 style={styles.title}>Add Student</h2>
      <form onSubmit={handleSubmit} style={styles.form}>
        <div style={styles.formGroup}>
          <label style={styles.label}>Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter student name"
            style={styles.input}
            required
          />
        </div>

        <div style={styles.formGroup}>
          <label style={styles.label}>Course</label>
          <input
            type="text"
            value={course}
            onChange={(e) => setCourse(e.target.value)}
            placeholder="Enter course name"
            style={styles.input}
            required
          />
        </div>

        <button type="submit" style={styles.button}>Add</button>
        {error && <div style={styles.error}>{error}</div>}
        {success && <div style={styles.success}>{success}</div>}

      </form>
    </div>
  </div>
  )
}
const styles = {
  wrapper: {
    display: "flex",
    justifyContent: "center",
    marginTop: "40px",
  },
  card: {
    backgroundColor: "#f9f9f9",
    padding: "30px",
    borderRadius: "10px",
    width: "100%",
    maxWidth: "400px",
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    border: "1px solid #e3e3e3",
  },
  title: {
    textAlign: "center",
    color: "#222",
    marginBottom: "20px",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: "16px",
  },
  formGroup: {
    display: "flex",
    flexDirection: "column",
  },
  label: {
    marginBottom: "6px",
    fontSize: "14px",
    fontWeight: "600",
    color: "#333",
  },
  input: {
    padding: "10px",
    fontSize: "14px",
    border: "1px solid #ccc",
    borderRadius: "6px",
  },
  button: {
    padding: "12px",
    backgroundColor: "rgb(210 133 25)",
    color: "#fff",
    fontSize: "15px",
    fontWeight: "bold",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    transition: "background 0.3s",
  },
  
  error: {
    color: "red",
    marginTop: "10px",
    fontWeight: "500",
  },
  success: {
    color: "green",
    marginTop: "10px",
    fontWeight: "500",
  },
  
};
export default StudentForm
