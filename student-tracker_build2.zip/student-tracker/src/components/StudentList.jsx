import React, { useState } from 'react'
import { collection, getDocs, query, orderBy } from 'firebase/firestore'
import { db } from '../firebase'

// This component implements the "Read" operation.
// It only fetches when the user clicks "Load Students", as required.
const StudentList = () => {
  const [students, setStudents] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const loadStudents = async () => {
    setLoading(true)
    setError(null)
    try {
      // Create a query that orders by createdAt (newest first)
      // Note: For brand new docs, createdAt can be null until the server timestamp resolves,
      // but in practice it will exist by the time we read.
      const q = query(collection(db, 'students'), orderBy('createdAt', 'desc'))
      const snap = await getDocs(q)

      // Convert each Firestore document to a plain object with its id for React keys
      const results = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }))
      setStudents(results)
    } catch (err) {
      console.error('Error loading students:', err)
      setError('Failed to load students. Check console for details.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="card">
      <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
        <h2 style={{ margin: 0 }}>Students</h2>
        <button className="ghost" onClick={loadStudents} disabled={loading}>
          {loading ? 'Loading...' : 'Load Students'}
        </button>
      </div>
      {error && <div className="error" style={{ marginTop: '0.5rem' }}>{error}</div>}

      <div style={{ marginTop: '0.75rem' }}>
        {students.length === 0 ? (
          <p className="muted">No students loaded yet. Click "Load Students" to fetch data.</p>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Course</th>
              </tr>
            </thead>
            <tbody>
              {students.map(s => (
                <tr key={s.id}>
                  <td>{s.name || '—'}</td>
                  <td>{s.course || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}

export default StudentList
