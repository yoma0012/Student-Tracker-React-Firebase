# Student Tracker (Vite + React + Firebase Firestore)

This project implements the **Create** and **Read** requirements for the Student Tracker exam.

## 1) Install
```bash
npm i
```

## 2) Configure Firebase
1. Create a Firebase project + Firestore database (in "Test mode" for quick setup).
2. Copy `.env.example` to `.env` and fill in your config values from the Firebase Console.
3. Make sure Firestore is enabled in *Build → Firestore Database*.

## 3) Run
```bash
npm run dev
```

## 4) Features implemented
- **Create Operation (StudentForm.jsx):**
  - Adds `{ name, course, createdAt }` to collection **students** using `addDoc(...)`.
  - Resets form on success and shows friendly messages.
  - Catches and logs errors to console.
- **Read Operation (StudentList.jsx):**
  - Click **Load Students** to fetch students on-demand using `getDocs(...)`.
  - Displays results in a table (name, course).
  - Clicking the button again refreshes the list (useful after adding new records).
- **Firebase Setup:**
  - `src/firebase.js` initializes Firebase app and exports `db` via `getFirestore()`.
  - Reads credentials from `.env` (Vite-style `import.meta.env.VITE_*`).

## 5) Screenshot for submission
After adding at least one student, open your Firebase Console → Firestore → **students**
and take a screenshot that clearly shows the document you added. Save it as
`firestore_screenshot.png` and upload it separately as required.

---
*Tip:* If you get a Firestore permissions error, check the Firestore Security Rules
or ensure you're using the correct Firebase project credentials in `.env`.
